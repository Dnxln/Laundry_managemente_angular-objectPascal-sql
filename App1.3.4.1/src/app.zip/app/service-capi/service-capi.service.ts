import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { CapiData } from '../view-capi-tab/view-capi-tab.component';


@Injectable({
  providedIn: 'root'
})
export class ServiceCapiService {

  constructor(private http: HttpClient) { }

  getCapiData(): Observable<CapiData[]> {
    //return this.http.get('./assets/capi.json');
    return this.http.get<CapiData[]>('http://127.0.0.1:8888/capi');
  }

  getCapiDataByID(id: number): Observable<CapiData[]> {
    //return this.http.get('./assets/capi.json');
    return this.http.get<CapiData[]>(`http://127.0.0.1:8888/capi?ID=${id}`);
  }

}