import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { ServiceLavorazioniService } from '../service-lavorazioni/service-lavorazioni.service';
import { MatPaginator } from '@angular/material/paginator';
import { MatSelectChange } from '@angular/material/select';
import { HttpErrorResponse } from '@angular/common/http';



export interface LavorazioniData {
  id: number;
  descrizione: string;
  versionID: number;
  [key: string]: number | string; // Firma dell'indice per consentire l'accesso tramite stringa
}

interface ID {
  value: number; // Rappresenta l'ID
  viewValue: string; // Rappresenta la visualizzazione dell'ID
}

@Component({
  selector: 'app-view-lavorazioni-tab',
  templateUrl: './view-lavorazioni-tab.component.html',
  styleUrls: ['./view-lavorazioni-tab.component.css']
})

export class ViewLavorazioniTabComponent implements OnInit{
  @ViewChild('paginatorLavorazioni') paginatorLavorazioni!: MatPaginator;

  IDs: ID[] = [];
  selectedID: number | null = -1;
  selectedIDForm: number | null = null;


  constructor(
    private serviceLavorazioniService: ServiceLavorazioniService
  ) {}


  ngOnInit() {
    this.serviceLavorazioniService.getLavorazioniData().subscribe((data: LavorazioniData[]) => {
      this.dataSourceLavorazioni.data = data;
      this.dataSourceLavorazioni.paginator = this.paginatorLavorazioni;

      this.IDs = data.map((item: LavorazioniData) => ({ value: item.id, viewValue: item.id.toString() }));
      this.IDs.unshift({ value: -1, viewValue: 'Nan' });
    }); 
    
    this.serviceLavorazioniService.getLavorazioniDataByID(this.selectedID !== null ? this.selectedID : -1).subscribe((data: LavorazioniData[]) => {
      this.dataSourceLavorazioniID.data = data;
    
      this.IDs.unshift({ value: -1, viewValue: 'Nan' });
    });


    document.addEventListener('keydown', (event) => {
      this.handleKeyPress(event);
    });
  }


  dataSourceLavorazioni = new MatTableDataSource<LavorazioniData>([]);
  dataSourceLavorazioniID = new MatTableDataSource<LavorazioniData>([]);
  displayedColumnsLavorazioni: string[] = ['id', 'descrizione', 'versionID'];
  public descrizioneLavorazione: string | null = null;


  handleKeyPress(event: KeyboardEvent) {
    if (event.key === 'Enter') {
      console.log("ao")
      this.filtraLavorazioniTable();
    }
  }

  filtraLavorazioniTable() {
    const filterPrefix = 'f:';
    const categorySeparator = '#';
  
    this.dataSourceLavorazioni.filterPredicate = (data: LavorazioniData, filter: string) => {
      let filterParts = filter.startsWith(filterPrefix) ? filter.substring(filterPrefix.length).split(categorySeparator) : [];
      let category = filterParts[0]?.toLowerCase();
      let value = filterParts[1]?.toLowerCase();
      let inputValue = filter.trim().toLowerCase();
      let properties = ['id', 'descrizione', 'versionID'];
  
      if (category && value) {
        let categoryValue = data[category]?.toString().toLowerCase();
        return categoryValue === value;
      }
  
      return properties.some(prop => data[prop]?.toString().toLowerCase() === inputValue);
    };
  
    if (this.descrizioneLavorazione) {
      this.dataSourceLavorazioni.filter = this.descrizioneLavorazione.toLowerCase();
    } else {
      this.descrizioneLavorazione = null;
      this.dataSourceLavorazioni.filter = '';
    }
  }
  

  customFilterPredicate(data: LavorazioniData, filter: string): boolean {
    const selectedID = parseInt(filter, 10);
    return data.id === selectedID;
  }


  handleSelectionChange(event: MatSelectChange) {
    const selectedID = event.value !== null ? event.value : null;
    if (this.selectedID !== selectedID) {
      this.selectedID = selectedID;
      this.serviceLavorazioniService.getLavorazioniDataByID(selectedID).subscribe({
        next: (data) => {
          this.dataSourceLavorazioniID.data = data;
        },
        error: (error: HttpErrorResponse)=> {
          this.dataSourceLavorazioniID.data = [];
          console.log(error)
        }
      });
    }
  }


  handleRowClick(record: LavorazioniData) {
    if (this.selectedID !== record.id) {
      this.selectedID = record.id;
      this.serviceLavorazioniService.getLavorazioniDataByID(record.id).subscribe({
        next: (data) => {
          this.dataSourceLavorazioniID.data = data;
        },
        error: (error: HttpErrorResponse)=> {
          this.dataSourceLavorazioniID.data = [];
          console.log(error)
        }
      });
      this.selectedIDForm = this.selectedID;
    } else {
      this.selectedID = -1; // Deseleziona la riga se viene cliccata di nuovo
      this.dataSourceLavorazioniID.data = [];
      this.selectedIDForm = null;
    }
  }

}