import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { ServiceCapiService } from '../service-capi/service-capi.service';
import { MatPaginator } from '@angular/material/paginator';
import { MatSelectChange } from '@angular/material/select';
import { HttpErrorResponse } from '@angular/common/http';


export interface CapiData {
  id: number;
  descrizione: string;
  versionID: number;
  [key: string]: number | string; // Firma dell'indice per consentire l'accesso tramite stringa
}

interface ID {
  value: number; // Rappresenta l'ID
  viewValue: string; // Rappresenta la visualizzazione dell'ID
}

@Component({
  selector: 'app-view-capi-tab',
  templateUrl: './view-capi-tab.component.html',
  styleUrls: ['./view-capi-tab.component.css']
})

export class ViewCapiTabComponent implements OnInit {
  @ViewChild('paginatorCapi') paginatorCapi!: MatPaginator;

  IDs: ID[] = [];
  selectedID: number | null = -1;
  selectedIDForm: number | null = null;

  
  constructor(
    private serviceCapiService: ServiceCapiService
  ) {}


  ngOnInit() {
    this.serviceCapiService.getCapiData().subscribe((data: CapiData[]) => {
      this.dataSourceCapi.data = data;
      this.dataSourceCapi.paginator = this.paginatorCapi;
    
      this.IDs = data.map((item: CapiData) => ({ value: item.id, viewValue: item.id.toString() }));
      this.IDs.unshift({ value: -1, viewValue: 'Nan' });
    });
    
    this.serviceCapiService.getCapiDataByID(this.selectedID !== null ? this.selectedID : -1).subscribe((data: CapiData[]) => {
      this.dataSourceCapiID.data = data;
    
      this.IDs.unshift({ value: -1, viewValue: 'Nan' });
    });
    

    document.addEventListener('keydown', (event) => {
      this.handleKeyPress(event);
    });
  }
  

  dataSourceCapi = new MatTableDataSource<CapiData>([]);
  dataSourceCapiID = new MatTableDataSource<CapiData>([]);
  displayedColumnsCapi: string[] = ['id', 'descrizione', 'versionID'];
  public descrizioneCapo: string | null = null;


  handleKeyPress(event: KeyboardEvent) {
    if (event.key === 'Enter') {
      console.log("ao")
      this.filtraCapiTable();
    }
  }

  filtraCapiTable() {
  const filterPrefix = 'f:';
  const categorySeparator = '#';

  this.dataSourceCapi.filterPredicate = (data: CapiData, filter: string) => {
    let filterParts = filter.startsWith(filterPrefix) ? filter.substring(filterPrefix.length).split(categorySeparator) : [];
    let category = filterParts[0]?.toLowerCase();
    let value = filterParts[1]?.toLowerCase();
    let inputValue = filter.trim().toLowerCase();
    let properties = ['id', 'descrizione', 'versionID'];

    if (category && value) {
      let categoryValue = data[category]?.toString().toLowerCase();
      return categoryValue === value;
    }

    return properties.some(prop => data[prop]?.toString().toLowerCase() === inputValue);
  };

  if (this.descrizioneCapo) {
    this.dataSourceCapi.filter = this.descrizioneCapo.toLowerCase();
  } else {
    this.descrizioneCapo = null;
    this.dataSourceCapi.filter = '';
  }
}


  customFilterPredicate(data: CapiData, filter: string): boolean {
    const selectedID = parseInt(filter, 10);
    return data.id === selectedID;
  }

  
  handleSelectionChange(event: MatSelectChange) {
    const selectedID = event.value !== null ? event.value : null;
    if (this.selectedID !== selectedID) {
      this.selectedID = selectedID;
      this.serviceCapiService.getCapiDataByID(selectedID).subscribe({
        next: (data) => {
          this.dataSourceCapiID.data = data;
        },
        error: (error: HttpErrorResponse)=> {
          this.dataSourceCapiID.data = [];
          console.log(error)
        }
      });
    }
  }
  
  

  handleRowClick(record: CapiData) {
    if (this.selectedID !== record.id) {
      this.selectedID = record.id;
      this.serviceCapiService.getCapiDataByID(record.id).subscribe({
        next: (data) => {
          this.dataSourceCapiID.data = data;
        },
        error: (error: HttpErrorResponse)=> {
          this.dataSourceCapiID.data = [];
          console.log(error)
        }
      });
      this.selectedIDForm = this.selectedID;
    } else {
      this.selectedID = -1; // Deseleziona la riga se viene cliccata di nuovo
      this.dataSourceCapiID.data = [];
      this.selectedIDForm = null;
    }
  }

}
