import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { ServiceClientiService } from '../service-clienti/service-clienti.service';
import { MatPaginator } from '@angular/material/paginator';
import { MatSelectChange } from '@angular/material/select';
import { HttpErrorResponse } from '@angular/common/http';


export interface ClientiData {
  id: number;
  nome: string;
  cognome: string;
  indirizzo: string;
  telefono: string;
  giorno: number;
  mese: number;
  versionID: number;
  [key: string]: number | string; // Firma dell'indice per consentire l'accesso tramite stringa
}

interface ID {
  value: number; // Rappresenta l'ID
  viewValue: string; // Rappresenta la visualizzazione dell'ID
}

@Component({
  selector: 'app-view-clienti-tab',
  templateUrl: './view-clienti-tab.component.html',
  styleUrls: ['./view-clienti-tab.component.css']
})

export class ViewClientiTabComponent implements OnInit{
  @ViewChild('paginatorClienti') paginatorClienti!: MatPaginator;

  IDs: ID[] = [];
  selectedID: number | null = -1;
  selectedIDForm: number | null = null;


  constructor(
    private serviceClientiService: ServiceClientiService
  ) {}


  ngOnInit() {
    this.serviceClientiService.getClientiData().subscribe((data: ClientiData[]) => {
      this.dataSourceClienti.data = data;
      this.dataSourceClienti.paginator = this.paginatorClienti;

      this.IDs = data.map((item: ClientiData) => ({ value: item.id, viewValue: item.id.toString() }));
      this.IDs.unshift({ value: -1, viewValue: 'Nan' });
    });

    this.serviceClientiService.getClientiDataByID(this.selectedID !== null ? this.selectedID : -1).subscribe((data: ClientiData[]) => {
      this.dataSourceClientiID.data = data;
    
      this.IDs.unshift({ value: -1, viewValue: 'Nan' });
    });
    

    document.addEventListener('keydown', (event) => {
      this.handleKeyPress(event);
    });
  }


  dataSourceClienti = new MatTableDataSource<ClientiData>([]);
  dataSourceClientiID = new MatTableDataSource<ClientiData>([]);
  displayedColumnsClienti: string[] = ['id', 'nome', 'cognome', 'indirizzo', 'telefono', 'giorno', 'mese', 'versionID'];
  public nome: string | null = null;


  handleKeyPress(event: KeyboardEvent) {
    if (event.key === 'Enter') {
      console.log("ao")
      this.filtraClientiTable();
    }
  }

  filtraClientiTable() {
    const filterPrefix = 'f:';
    const categorySeparator = '#';
  
    this.dataSourceClienti.filterPredicate = (data: ClientiData, filter: string) => {
      let filterParts = filter.startsWith(filterPrefix) ? filter.substring(filterPrefix.length).split(categorySeparator) : [];
      let category = filterParts[0]?.toLowerCase();
      let value = filterParts[1]?.toLowerCase();
      let inputValue = filter.trim().toLowerCase();
      let properties = ['id', 'nome', 'cognome', 'indirizzo', 'telefono', 'giorno', 'mese', 'versionID'];
  
      if (category && value) {
        let categoryValue = data[category]?.toString().toLowerCase();
        return categoryValue === value;
      }
  
      return properties.some(prop => data[prop]?.toString().toLowerCase() === inputValue);
    };
  
    if (this.nome) {
      this.dataSourceClienti.filter = this.nome.toLowerCase();
    } else {
      this.nome = null;
      this.dataSourceClienti.filter = '';
    }
  }
  

  customFilterPredicate(data: ClientiData, filter: string): boolean {
    const selectedID = parseInt(filter, 10);
    return data.id === selectedID;
  }

  handleSelectionChange(event: MatSelectChange) {
    const selectedID = event.value !== null ? event.value : null;
    if (this.selectedID !== selectedID) {
      this.selectedID = selectedID;
      this.serviceClientiService.getClientiDataByID(selectedID).subscribe({
        next: (data) => {
          this.dataSourceClientiID.data = data;
        },
        error: (error: HttpErrorResponse)=> {
          this.dataSourceClientiID.data = [];
          console.log(error)
        }
      });
    }
  }


  handleRowClick(record: ClientiData) {
    if (this.selectedID !== record.id) {
      this.selectedID = record.id;
      this.serviceClientiService.getClientiDataByID(record.id).subscribe({
        next: (data) => {
          this.dataSourceClientiID.data = data;
        },
        error: (error: HttpErrorResponse)=> {
          this.dataSourceClientiID.data = [];
          console.log(error)
        }
      });
      this.selectedIDForm = this.selectedID;
    } else {
      this.selectedID = -1; // Deseleziona la riga se viene cliccata di nuovo
      this.dataSourceClientiID.data = [];
      this.selectedIDForm = null;
    }
  }
  

}
